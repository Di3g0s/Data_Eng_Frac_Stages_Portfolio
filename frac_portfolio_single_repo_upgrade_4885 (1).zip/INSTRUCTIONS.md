# Upgrade your ONE existing GitHub repository — no V2 copy

Target: `Di3g0s/Data_Eng_Frac_Stages_Portfolio`

The upgrade modifies **12 specified code and documentation files in the same working tree**. It does not create another repository, clone, branch, or remote. It does not delete, regenerate, move, untrack, or overwrite ANY existing `.csv`, `.xls`, `.xlsx` or `.xlsm` files. The installer requires these four files to already be present: two original Stage 1/Stage 2 treatment workbooks, `WITS_starter/data/prepared/canonical.csv`, and `WITS_starter/canonical_header.csv`. Other spreadsheets and CSV files are also hashed and preserved.

## In your existing Codespace

1. Upload `frac_portfolio_single_repo_upgrade.zip` into the **current** Codespace and open a terminal in the repository root.
2. Extract the upgrade files to `/tmp`, **not** into a second repository:

```bash
mkdir -p /tmp/frac-portfolio-upgrade
unzip -oq frac_portfolio_single_repo_upgrade.zip -d /tmp/frac-portfolio-upgrade
```

3. Preview the changes without altering anything:

```bash
python /tmp/frac-portfolio-upgrade/apply_to_existing_repo.py --repository .
```

4. Apply them **to the same repository**:

```bash
python /tmp/frac-portfolio-upgrade/apply_to_existing_repo.py --repository . --apply
```

The installer refuses to overwrite uncommitted changes in any of the affected files: commit or stash your modifications first. It checks SHA-256 hashes of all spreadsheet/CSV files before and after applying and backs up only overwritten source/docs files under `~/.local/share/frac-portfolio-upgrade-backups/` (not a second repo).

5. Install dependencies and test:

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s WITS_starter -p 'test_*.py' -v
git status --short
git diff --stat
```

6. Review and publish changes to the SAME GitHub repository:

```bash
git add -- .gitignore .github/workflows/ci.yml README.md README_WITS.md \
    requirements.txt docs/ WITS_starter/data/raw_2_prepared.py \
    WITS_starter/upload_loop.py WITS_starter/test_prepare.py WITS_starter/test_uploader.py

git diff --cached --stat
git commit -m "Improve frac data engineering portfolio documentation and reproducibility"
git push origin main
```

If your current branch is not `main`, push your active branch instead (see `git branch --show-current`). This procedure does **not** remove or untrack the existing Excel and CSV files. If you edited the source data locally, review `git status` and stage those desired data changes separately (after checking your rights to publish them).

## What's changed?

- Project-specific README and Mermaid pipeline architecture diagram, with honest implementation status.
- Documentation for data lineage, reliability, security, limitations and roadmap.
- Runtime dependencies (`pandas`, `openpyxl`, `databricks-sdk`) declared in `requirements.txt`.
- Stage-specific Excel adapter preserving original worksheet row numbers; it refuses to overwrite existing CSVs without `--overwrite`.
- Auth-flexible Databricks uploader (your `frac-demo` profile still works) and `--once` mode.
- Six+ new synthetic/offline tests plus GitHub Actions CI.
- `.gitignore` for Python caches and secrets, **without ignoring the source Excel or prepared CSV folders**.

### Why aren't the workbooks inside this small ZIP?

They are already in your existing **single** repository. Copying them into an upgrade archive and then reimporting would be redundant and would risk overwriting your original data. The installer verifies that the originals are present and unchanged. If they are missing locally, `git pull --ff-only` from your repository is the safest way to retrieve them before applying the upgrade.

**GitHub connection limitation:** The GitHub integration returned `403 Resource not accessible by integration` for branch creation. The ZIP is provided so you can apply and push the work from your authenticated Codespace; no remote repository was modified by ChatGPT.
