#!/usr/bin/env python3
"""Safely update ONE existing Git repository without moving or editing data files.

Run from the root of Di3g0s/Data_Eng_Frac_Stages_Portfolio:
  python /tmp/frac-upgrade/apply_to_existing_repo.py --repository .
  python /tmp/frac-upgrade/apply_to_existing_repo.py --repository . --apply

The default mode previews changes. With --apply, it copies only selected text
source/docs into the SAME working tree. It does not create a second Git checkout,
branch, commit, or remote repository. All original Excel and CSV files stay in
place and are SHA-256 checked before/after. Replaced text files are backed up
outside the checkout in ~/.local/share/frac-portfolio-upgrade-backups/.
"""
from __future__ import annotations

import argparse
import hashlib
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

OVERLAY = (
    '.gitignore',
    '.github/workflows/ci.yml',
    'README.md',
    'README_WITS.md',
    'requirements.txt',
    'docs/ARCHITECTURE.md',
    'docs/ROADMAP.md',
    'docs/DATA_ASSETS.md',
    'WITS_starter/data/raw_2_prepared.py',
    'WITS_starter/upload_loop.py',
    'WITS_starter/test_prepare.py',
    'WITS_starter/test_uploader.py',
)
REQUIRED_DATA = (
    'WITS_starter/data/raw/16B(78)-32_Stage 1_Treatment Data.xlsx',
    'WITS_starter/data/raw/16B(78)-32_Stage 2_Treatment Data.xlsx',
    'WITS_starter/data/prepared/canonical.csv',
    'WITS_starter/canonical_header.csv',
)
EXCLUDE_DIRS = {
    '.git', '.venv', 'venv', '__pycache__', '.pytest_cache', '.mypy_cache',
    '.ruff_cache', '.ipynb_checkpoints', 'node_modules',
}
DATA_SUFFIXES = {'.xlsx', '.xls', '.xlsm', '.csv'}


def checksum(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(part)
    return digest.hexdigest()


def data_inventory(repo: Path) -> dict[str, str]:
    for item in REQUIRED_DATA:
        if not (repo / item).is_file():
            raise FileNotFoundError(f'Required data file is missing: {item}')
    result: dict[str, str] = {}
    for current_dir, subdirs, files in os.walk(repo):
        subdirs[:] = [name for name in subdirs if name not in EXCLUDE_DIRS]
        for name in files:
            path = Path(current_dir) / name
            if path.suffix.lower() in DATA_SUFFIXES and path.is_file() and not path.is_symlink():
                result[path.relative_to(repo).as_posix()] = checksum(path)
    return result


def git(repo: Path, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(['git', '-C', str(repo), *args], check=True,
                          text=True, capture_output=True)


def validate_root(repo: Path) -> None:
    if not (repo / 'WITS_starter' / 'replay.py').is_file():
        raise ValueError('Not the expected frac-treatment portfolio repository.')
    try:
        root = Path(git(repo, 'rev-parse', '--show-toplevel').stdout.strip()).resolve()
    except (FileNotFoundError, subprocess.CalledProcessError) as exc:
        raise ValueError('Git is required. Run this from your existing Git checkout.') from exc
    if root != repo:
        raise ValueError(f'Use the Git repository root, not a subfolder. Root: {root}')


def changes_from_overlay(upgrade_dir: Path, repo: Path) -> list[str]:
    changed = []
    for item in OVERLAY:
        proposed = upgrade_dir / item
        if not proposed.is_file():
            raise FileNotFoundError(f'Upgrade package is incomplete: {item}')
        existing = repo / item
        if not existing.is_file() or checksum(existing) != checksum(proposed):
            changed.append(item)
    return changed


def dirty_upgrade_targets(repo: Path, paths: list[str]) -> list[str]:
    if not paths:
        return []
    status = git(repo, 'status', '--porcelain=v1', '--untracked-files=all', '--', *paths).stdout
    return [line for line in status.splitlines() if line]


def apply(repo: Path, upgrade_dir: Path, changes: list[str], before: dict[str, str]) -> Path:
    now = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    backups = Path.home() / '.local' / 'share' / 'frac-portfolio-upgrade-backups'
    backups.mkdir(parents=True, exist_ok=True)
    backup = backups / f'{now}-{os.getpid()}'
    backup.mkdir(exist_ok=False)
    existing = [item for item in changes if (repo / item).exists()]
    added = [item for item in changes if not (repo / item).exists()]
    for item in existing:
        dest = backup / item
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(repo / item, dest)

    try:
        for item in changes:
            destination = repo / item
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(upgrade_dir / item, destination)
        after = data_inventory(repo)
        if before != after:
            raise RuntimeError('Data checksum mismatch after apply; recovering previous text files.')
    except Exception:
        for item in existing:
            shutil.copy2(backup / item, repo / item)
        for item in added:
            (repo / item).unlink(missing_ok=True)
        raise
    return backup


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repository', type=Path, default=Path.cwd(),
                        help='Existing repository root (default: current directory)')
    parser.add_argument('--apply', action='store_true',
                        help='Apply reviewed changes IN PLACE, leaving Excel and CSV bytes unchanged')
    args = parser.parse_args()
    repo = args.repository.resolve()
    upgrade_dir = Path(__file__).resolve().parent
    try:
        validate_root(repo)
        before = data_inventory(repo)
        changes = changes_from_overlay(upgrade_dir, repo)
        dirty = dirty_upgrade_targets(repo, changes)
    except (OSError, RuntimeError, ValueError, subprocess.CalledProcessError) as exc:
        parser.exit(1, f'ERROR: {exc}\n')

    print(f'Existing Git repository: {repo}')
    print(f'Data files verified: {len(before)} (.xlsx/.xls/.xlsm/.csv). No data files will change.')
    print(f'Upgrade files to add/replace: {len(changes)}')
    for item in changes:
        action = 'REPLACE' if (repo / item).exists() else 'ADD'
        print(f'  {action:7} {item}')
    if not changes:
        print('Already up to date. Excel and CSV files were checked and left untouched.')
        return
    if dirty:
        print('\nChanges already present in files the upgrade would touch:')
        for item in dirty:
            print('  ' + item)
        print('Commit or stash those edits first so the upgrader never overwrites uncommitted code.')
        if args.apply:
            parser.exit(2, 'ABORTED: No files changed.\n')

    if not args.apply:
        print('\nPreview only: original checkout unchanged.')
        print('Use --apply to upgrade this SAME repository. No second repo will be created.')
        return
    try:
        backup = apply(repo, upgrade_dir, changes, before)
    except (OSError, RuntimeError, ValueError) as exc:
        parser.exit(1, f'ERROR applying upgrade: {exc}\n')
    print(f'\nUpdated {len(changes)} source/docs files in your EXISTING repository.')
    print(f'All {len(before)} Excel/CSV data files retained byte-for-byte (SHA-256 verified).')
    print(f'Backups for replaced code/docs (NOT a duplicate repo): {backup}')
    print('Next: git diff --stat, run tests, then commit and git push.')


if __name__ == '__main__':
    main()
